Internal Combustion Engine
==========================

This namespace is dedicated to all types of internal combustion engines.
