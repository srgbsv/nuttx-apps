This directory contains the DSDL for the ArduPilot vendor specific
DroneCAN messages.

For service messages we use IDs starting at 200

For non-service messages we use IDs starting at 20000

https://dronecan.github.io/Specification/5._Application_level_conventions/#id-distribution
