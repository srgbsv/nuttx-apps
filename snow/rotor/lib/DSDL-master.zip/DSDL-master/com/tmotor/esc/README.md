T-Motor   CAN ESC
-----------------

These messages are for the T-Motor DroneCAN ESCs. The DSDL was
provided by T-Motor
