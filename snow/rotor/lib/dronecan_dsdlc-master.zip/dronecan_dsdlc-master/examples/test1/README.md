This demonstrates running the compiler to generate the C headers, and
running the test suite
